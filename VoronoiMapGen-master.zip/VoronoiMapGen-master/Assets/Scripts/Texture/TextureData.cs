﻿using UnityEngine;
using UnityEditor;
using System;

public class TextureData
{
    public Color[] colours;
}