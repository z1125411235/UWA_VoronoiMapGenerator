﻿using System;
using UnityEngine;
[Serializable]
public class MapNodeTypeColor
{
    public MapGraph.MapNodeType type;
    public Color color;
}
