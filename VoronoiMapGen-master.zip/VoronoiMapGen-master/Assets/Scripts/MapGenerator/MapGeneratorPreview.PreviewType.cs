﻿public partial class MapGeneratorPreview
{
    public enum PreviewType
    {
        Map,
        HeightMap
    }
}
