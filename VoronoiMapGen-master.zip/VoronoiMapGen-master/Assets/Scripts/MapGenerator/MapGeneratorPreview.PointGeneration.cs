﻿public partial class MapGeneratorPreview
{
    public enum PointGeneration
    {
        Random,
        PoissonDisc,
        OffsetGrid,
        Grid
    }
}
